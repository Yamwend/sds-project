export const EntityNavbarItems = [];
