export enum TypeConsultation {
  CPN = 'CPN',

  CPON = 'CPON',

  CPS = 'CPS',

  CURATIVE = 'CURATIVE',

  BILAN = 'BILAN',
}
