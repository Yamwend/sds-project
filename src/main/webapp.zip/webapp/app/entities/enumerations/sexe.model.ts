export enum Sexe {
  MASCULIN = 'MASCULIN',

  FEMININ = 'FEMININ',

  AUTRES = 'AUTRES',
}
